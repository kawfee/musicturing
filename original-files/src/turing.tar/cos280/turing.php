<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Musical Turing Test</title>
    </head>
    <body>
        <h4>Musical Turing Test</h4>
		<h1>Song List</h1>
		<!-- <form action="turing_submit.php" method="get" accept-charset="utf-8"> -->
		<ol>
		<?php
			$filetype = "midi";
			$files = glob(dirname(__FILE__) . "/*." . $filetype);
			shuffle($files);
			if(sizeof($files) == 0) {
				print "<p>Sorry, no $filetype files were found.</p>";
			}
			$date = getdate();
			$strdate = $date["year"] . "-" . $date["mon"] . "-" . $date["mday"] . " - " . $date["hours"] . ";" . $date["minutes"] . ";" . $date["seconds"];
			$handle = fopen("MusicTuring-" . $strdate . ".txt", "w");
			for ($i=0; $i<sizeof($files); $i++) {
				preg_match('/([^\/]+)$/', $files[$i], $matches);
				fwrite($handle, $matches[0] . "\n");
				print "<li><embed src=\"$matches[0]\" width=\"140\" height=\"20\" autostart=\"false\" loop=\"FALSE\">";
				#print "<input type=\"radio\" name=\"song$i\" value=\"human\">Human";
				#print "<input type=\"radio\" name=\"song$i\" value=\"computer\">Computer";
				print "</li><br />";
				#print '<li><a href="' . $matches[0] . '">' . $matches[0] . '</a></li>';
			}
			fclose($handle);
		?>
			<!-- <p><input type="submit" value="Submit &rarr;"></p> -->
		</ol>		
		<!-- </form> -->
    </body>
</html>
